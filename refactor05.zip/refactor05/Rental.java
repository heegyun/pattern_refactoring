package refactor05;

/*
 * �뿩 ���� Ŭ����
 */

public class Rental {
	private Movie movie;	 	//�뿩��ȭ
	private int daysRented;		//�뿩�Ⱓ
	
	public Rental(Movie movie, int daysRented) {
		this.movie = movie;
		this.daysRented = daysRented;
	}

	public Movie getMovie() {
		return movie;
	}
	

	public int getDaysRented() {
		return daysRented;
	}
	// Moved Here
	int getCharge() {
		int price = 0;
		// ���� ������ �뿩�� ���
		switch(getMovie().getPriceCode()) {
		case REGULAR:
			price +=2000;
			if(getDaysRented() > 2) 
				price+=(getDaysRented()-2) * 1500;
			break;			
		case NEW_RELEASE:
			price += getDaysRented() * 2000;
			break;
		case CHILDREN:
			price += 1500;
			if(getDaysRented() > 3) 
				price += (getDaysRented()-3)*1500;
			break;
			}
		return price;
	}

	// Move here
	int getFrequentRentalPoints() {
		//frequentRenterPoints+=100;
		
		//�ֽŹ��� ��Ʋ �̻� �뿩�ϸ� ���ʽ� ����Ʈ ����
		if(getMovie().getPriceCode() == Movie.PriceCode.NEW_RELEASE && getDaysRented()>1) 
			//frequentRenterPoints +=100;
			return 200;
		else return 100;
	}

	
	
	
}
