package refactor07;

/*
 *  �Ϲ� ��ȭ �뿩�ݰ� ������
 */
public class ReqularPrice implements Price{

	@Override
	public int getCharge(int daysRented) {
		int price = 2000;
		if(daysRented>2)
			price += (daysRented -2) *1500;
		return price;
	}

}
