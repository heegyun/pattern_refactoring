package refactor07;

/*
 * �뿩 ���� Ŭ����
 */

public class Rental {
	private Movie movie;	 	//�뿩��ȭ
	private int daysRented;		//�뿩�Ⱓ
	
	public Rental(Movie movie, int daysRented) {
		this.movie = movie;
		this.daysRented = daysRented;
	}

	public Movie getMovie() {
		return movie;
	}
	

	public int getDaysRented() {
		return daysRented;
	}

	public int getCharge() {
		return movie.getCharge(daysRented);
	}
	
	public int getFrequentRentalPoints(){
		return movie.getCharge(daysRented);
	}
}
