package refactoring.examples.printer.three_2;

public abstract class Printer implements Printable {

	protected String ID;

	public Printer() {
		super();
	}

	public String getID() {
		return ID;
	}
	//���ø� �޼ҵ� 
	@Override
	public  void print(Object msg) {
		isPrintable();
		printing(msg);
	}

	//public abstract void print(Object msg) ;
	public abstract void printing(Object msg);
	public abstract void alert() ;
	public abstract boolean isPrintable() ;

	public void testPrinting() {
		print("�ƾ�~ ����Ʈ �׽�Ʈ. ����Ʈ �׽�Ʈ");												 
	}

}