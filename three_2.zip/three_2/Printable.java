package refactoring.examples.printer.three_2;

public interface Printable {

	//���ø� �޼ҵ� 
	void print(Object msg);

}