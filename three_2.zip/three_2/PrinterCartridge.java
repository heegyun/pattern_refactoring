package refactoring.examples.printer.three_2;

public class PrinterCartridge {
	public double capacity;
	public double reductionRate;

	public PrinterCartridge() {
	}
}