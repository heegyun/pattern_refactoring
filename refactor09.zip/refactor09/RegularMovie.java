package refactor09;

/*
 *  �Ϲ� ��ȭ �뿩�ݰ� ������
 */
public class RegularMovie extends Movie{

	public RegularMovie(String title) {
		super(title);
		
	}

	@Override
	public int getCharge(int daysRented) {
		int price = 2000;
		if(daysRented>2)
			price += (daysRented -2) *1500;
		return price;
	}

}
