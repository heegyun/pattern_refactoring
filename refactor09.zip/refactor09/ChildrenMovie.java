package refactor09;
/*
 * �Ƶ���ȭ �뿩�ݰ� ������
 */

public class ChildrenMovie extends Movie{

	public ChildrenMovie(String title) {
		super(title);
		// TODO Auto-generated constructor stub
	}

	@Override
	public int getCharge(int daysRented) {
		int price = 1500;
		if(daysRented>3) price +=(daysRented-3)*1500;
		return price;
		
	}

}
