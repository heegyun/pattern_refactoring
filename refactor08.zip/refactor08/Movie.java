package refactor08;

/*
 * ���� ������ Ŭ����
 */
public class Movie {
	private String title; 			//��ȭ����
	private PriceCode priceCode; 	//��ȭ�з��ڵ�
		
	public Movie(String title, PriceCode priceCode) {
		this.title = title;
		this.priceCode = priceCode;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public PriceCode getPriceCode() {
		return priceCode;
	}

		
	int getCharge(int daysRented) {
		
		return priceCode.getCharge(daysRented);
	}

	int getFrequentRentalPoints(int  daysRented) {				
		return priceCode.getFrequentRentalPoints(daysRented);
	}
	
}
